#' Simulate RNAseq data
#'
#' @param b fold change of the mean, default=4
#' @param ng number of genes, default=500
#' @param rep number of biological replicates, default=3
#' @param option c("mrf", "hmm"), simulated the latent states by Hidden Markov Model (HMM) or Markov Random Field Model (MRF)
#' @param paraMRF c(gamma, beta_sl, beta_si, beta_li, beta_t, beta_s), option="mrf", the parameters for the MRF model. See paper for description of the parameters
#' @param paraHMM c(nDE, tch, perc), option="hmm", the parameters for the HMM model. nDE: percentage of differential expression; tch: transition probability; perc: percentage of perturbation
#' @param shape dispersion parameter, default=0.85
#' @param scale dispersion parameter, default=0.5
#' @param ...
#' @return The simulated data
#' \item{data}{data matrix, rows are samples, columns are genes} 
#' \item{reg}{region/layer labels}
#' \item{tp}{time points}
#' \item{sex}{label for sex}
#' \item{states}{the latent states: 1, DE; 0, EE}
#' \item{group}{the group labels, samples in the same group will be pooled to calculate dispersion} 
#' \item{...}
#' @export
#' @examples
#' data_mrf <- getsimSeq(b=4, ng=500, rep = 3, option="mrf", paraMRF=c(-1.1, 2, 0.1, 2, 0.2, 1))
#' data_hmm <- getsimSeq(b=4, ng=500, rep = 3, option="hmm", paraHMM=c(0.1, 0.2, 0.2))
getsimSeq <- function(b=4, ng=500, rep = 3, option=c("mrf", "hmm"), 
                      paraMRF=NULL, paraHMM=NULL, iter=3, iprob = 0.5,
                      librarySize=NULL, lamda=NULL, shape = 0.85, scale = 0.5                    
                      )
{
  nbr=3; nt=5; numsex=2
  ###simulate the latent states
  if (option=="mrf"){
    if (is.null(paraMRF)){
      stop(stop("Please enter a valid paraMRF"))
    }
    states <- getStatesSimmrf(paraMRF=paraMRF, nbr=nbr, ng=ng, nt=nt, numsex=numsex, iter=iter, iprob=iprob)
  } else if (option=="hmm") {
    if (is.null(paraHMM)){
      stop(stop("Please enter a valid paraHMM"))
    }
    nDE <- paraHMM[1]; tch <- paraHMM[2]; perc <- paraHMM[3]
    states <- getStatesSimhmm(nbr=nbr, ng=ng, nt=nt, numsex=numsex, nDE=nDE, tch=tch, perc=perc)
  } else {
    stop(stop("Please enter a valid option: mrf or hmm"))
  }
  if (is.null(lamda)){
    lamda <- array(1/ng, dim=c(nbr, ng, numsex))
  }
  if (is.null(librarySize)){
    ###median of read count in the brain data around 200
    librarySize <- ng * runif(nbr * (nt + 1) * numsex * rep, min = 100, max = 300)
  }
  lall <- array(dim=c(nbr, ng, nt + 1, numsex))
  lall[,,1,] <- lamda
  ###the threshold for lamda
  lthres <- 1/ng/20
  getl <- function(lamda, states, b, lthres){
    ###don't want lamda to be too small to cause small counts
    tmp <- states[states==1] * (sample(2,length(states[states==1]),replace=T) - 1.5) * 2
    ln <- lamda
    ln[states == 1] <- lamda[states == 1] * b ^ tmp
    ln[ln <= lthres & states == 1] <- lamda[ln <= lthres & states == 1] * b
    return(ln)
  }
  for (t in 1:nt){
    lall[,,t + 1,] <- getl(lall[,,t,], states[,,t,], b, lthres)
  }
  #disp <- array(rgamma(length(lall), shape = 0.85, scale = 0.5), dim = dim(lall))
  ###assume each gene have one dispersion
  disp <- rgamma(ng, shape = 0.85, scale = 0.5)
  data <- c()
  breg <- c()
  tp <- c()
  sex <- c()
  group <- c()
  gid <- 1
  count <- 0
  for (b in 1:nbr){
    for (t in 1:(nt + 1)){
      for (s in 1:numsex){
        for (r in 1:rep){
          count <- count + 1
          lib <- librarySize[count]
          data <- cbind(data, matrix(rnbinom(n = ng, mu = lall[b,,t,s] * lib, 
                                             size = 1/disp),byrow = F, ncol = 1))
          group <- c(group, gid)
        } 
        breg <- c(breg, rep(b, rep))
        tp <- c(tp, rep(t, rep))
        sex <- c(sex, rep(s, rep))
        if (rep!=1){
          gid <- gid + 1
        }
      }
      if (rep==1){
        gid <- gid + 1
      }
    }
  }
  #print(count)
  return(list(reg = breg, tp = tp, sex = sex, data = data, states = states, group = group, 
              lamdaall = lall, librarySize = librarySize, dispersion = disp))
}

getStatesSimmrf <- function(paraMRF, nbr=3, ng=500, nt=5, numsex=2, iter=3, iprob = 0.5)
{
  g <- paraMRF[1]; bsl <- paraMRF[2]; bsi <- paraMRF[3]; 
  bli <- paraMRF[4]; bt <- paraMRF[5]; bsex <- paraMRF[6]
  
  states <- array(sample(2, nbr*ng*nt*numsex, replace=T, prob=c(1-iprob, iprob)) - 1, dim=c(nbr, ng, nt, numsex))
  for (it in 1:iter){
    br <- 1
    for (t in 1:nt){
      sex <- 1
      nsex <- 2
      if (t==1){
        ##the term when z=1
        t1 <- g + bsl*states[2,,t,sex] + bsi*states[3,,t,sex] + bt*states[br,,t+1,sex] + bsex*states[br,,t,nsex]
        ##the term when z=0
        t0 <- bsl*(1-states[2,,t,sex]) + bsi*(1-states[3,,t,sex]) + bt*(1-states[br,,t+1,sex]) + bsex*(1-states[br,,t,nsex])
      } else if(t==nt) {
        t1 <- g + bsl*states[2,,t,sex] + bsi*states[3,,t,sex] + bt*states[br,,t-1,sex] + bsex*states[br,,t,nsex]
        t0 <- bsl*(1-states[2,,t,sex]) + bsi*(1-states[3,,t,sex]) + bt*(1-states[br,,t-1,sex]) + bsex*(1-states[br,,t,nsex])
      } else {
        t1 <- g + bsl*states[2,,t,sex] + bsi*states[3,,t,sex] + bt*(states[br,,t-1,sex]+states[br,,t+1,sex]) + bsex*states[br,,t,nsex]
        t0 <- bsl*(1-states[2,,t,sex]) + bsi*(1-states[3,,t,sex]) + bt*(1-states[br,,t-1,sex]+1-states[br,,t+1,sex]) + bsex*(1-states[br,,t,nsex])
      }
      states[br,,t,sex] <- ((exp(t1)/(exp(t1) + exp(t0))) > runif(ng)) + 0
      sex <- 2
      nsex <- 1
      if (t==1){
        ##the term when z=1
        t1 <- g + bsl*states[2,,t,sex] + bsi*states[3,,t,sex] + bt*states[br,,t+1,sex] + bsex*states[br,,t,nsex]
        ##the term when z=0
        t0 <- bsl*(1-states[2,,t,sex]) + bsi*(1-states[3,,t,sex]) + bt*(1-states[br,,t+1,sex]) + bsex*(1-states[br,,t,nsex])
      } else if(t==nt) {
        t1 <- g + bsl*states[2,,t,sex] + bsi*states[3,,t,sex] + bt*states[br,,t-1,sex] + bsex*states[br,,t,nsex]
        t0 <- bsl*(1-states[2,,t,sex]) + bsi*(1-states[3,,t,sex]) + bt*(1-states[br,,t-1,sex]) + bsex*(1-states[br,,t,nsex])
      } else {
        t1 <- g + bsl*states[2,,t,sex] + bsi*states[3,,t,sex] + bt*(states[br,,t-1,sex]+states[br,,t+1,sex]) + bsex*states[br,,t,nsex]
        t0 <- bsl*(1-states[2,,t,sex]) + bsi*(1-states[3,,t,sex]) + bt*(1-states[br,,t-1,sex]+1-states[br,,t+1,sex]) + bsex*(1-states[br,,t,nsex])
      }
      states[br,,t,sex] <- ((exp(t1)/(exp(t1) + exp(t0))) > runif(ng)) + 0
    }
    br <- 2
    for (t in 1:nt){
      sex <- 1
      nsex <- 2
      if (t==1){
        t1 <- g + bsl*states[1,,t,sex] + bli*states[3,,t,sex] + bt*states[br,,t+1,sex] + bsex*states[br,,t,nsex]
        t0 <- bsl*(1-states[1,,t,sex]) + bli*(1-states[3,,t,sex]) + bt*(1-states[br,,t+1,sex]) + bsex*(1-states[br,,t,nsex])
      } else if(t==nt) {
        t1 <- g + bsl*states[1,,t,sex] + bli*states[3,,t,sex] + bt*states[br,,t-1,sex] + bsex*states[br,,t,nsex]
        t0 <- bsl*(1-states[1,,t,sex]) + bli*(1-states[3,,t,sex]) + bt*(1-states[br,,t-1,sex]) + bsex*(1-states[br,,t,nsex])
      } else {
        t1 <- g + bsl*states[1,,t,sex] + bli*states[3,,t,sex] + bt*(states[br,,t-1,sex]+states[br,,t+1,sex]) + bsex*states[br,,t,nsex]
        t0 <- bsl*(1-states[1,,t,sex]) + bli*(1-states[3,,t,sex]) + bt*(1-states[br,,t-1,sex]+1-states[br,,t+1,sex]) + bsex*(1-states[br,,t,nsex])
      }
      states[br,,t,sex] <- ((exp(t1)/(exp(t1) + exp(t0))) > runif(ng)) + 0
      sex <- 2
      nsex <- 1
      if (t==1){
        t1 <- g + bsl*states[1,,t,sex] + bli*states[3,,t,sex] + bt*states[br,,t+1,sex] + bsex*states[br,,t,nsex]
        t0 <- bsl*(1-states[1,,t,sex]) + bli*(1-states[3,,t,sex]) + bt*(1-states[br,,t+1,sex]) + bsex*(1-states[br,,t,nsex])
      } else if(t==nt) {
        t1 <- g + bsl*states[1,,t,sex] + bli*states[3,,t,sex] + bt*states[br,,t-1,sex] + bsex*states[br,,t,nsex]
        t0 <- bsl*(1-states[1,,t,sex]) + bli*(1-states[3,,t,sex]) + bt*(1-states[br,,t-1,sex]) + bsex*(1-states[br,,t,nsex])
      } else {
        t1 <- g + bsl*states[1,,t,sex] + bli*states[3,,t,sex] + bt*(states[br,,t-1,sex]+states[br,,t+1,sex]) + bsex*states[br,,t,nsex]
        t0 <- bsl*(1-states[1,,t,sex]) + bli*(1-states[3,,t,sex]) + bt*(1-states[br,,t-1,sex]+1-states[br,,t+1,sex]) + bsex*(1-states[br,,t,nsex])
      }
      states[br,,t,sex] <- ((exp(t1)/(exp(t1) + exp(t0))) > runif(ng)) + 0
    }
    br <- 3
    for (t in 1:nt){
      sex <- 1
      nsex <- 2
      if (t==1){
        t1 <- g + bsi*states[1,,t,sex] + bli*states[2,,t,sex] + bt*states[br,,t+1,sex] + bsex*states[br,,t,nsex]
        t0 <- bsi*(1-states[1,,t,sex]) + bli*(1-states[2,,t,sex]) + bt*(1-states[br,,t+1,sex]) + bsex*(1-states[br,,t,nsex])
      } else if(t==nt) {
        t1 <- g + bsi*states[1,,t,sex] + bli*states[2,,t,sex] + bt*states[br,,t-1,sex] + bsex*states[br,,t,nsex]
        t0 <- bsi*(1-states[1,,t,sex]) + bli*(1-states[2,,t,sex]) + bt*(1-states[br,,t-1,sex]) + bsex*(1-states[br,,t,nsex])
      } else {
        t1 <- g + bsi*states[1,,t,sex] + bli*states[2,,t,sex] + bt*(states[br,,t-1,sex]+states[br,,t+1,sex]) + bsex*states[br,,t,nsex]
        t0 <- bsi*(1-states[1,,t,sex]) + bli*(1-states[2,,t,sex]) + bt*(1-states[br,,t-1,sex]+1-states[br,,t+1,sex]) + bsex*(1-states[br,,t,nsex])
      }
      states[br,,t,sex] <- ((exp(t1)/(exp(t1) + exp(t0))) > runif(ng)) + 0
      sex <- 2
      nsex <- 1
      if (t==1){
        t1 <- g + bsi*states[1,,t,sex] + bli*states[2,,t,sex] + bt*states[br,,t+1,sex] + bsex*states[br,,t,nsex]
        t0 <- bsi*(1-states[1,,t,sex]) + bli*(1-states[2,,t,sex]) + bt*(1-states[br,,t+1,sex]) + bsex*(1-states[br,,t,nsex])
      } else if(t==nt) {
        t1 <- g + bsi*states[1,,t,sex] + bli*states[2,,t,sex] + bt*states[br,,t-1,sex] + bsex*states[br,,t,nsex]
        t0 <- bsi*(1-states[1,,t,sex]) + bli*(1-states[2,,t,sex]) + bt*(1-states[br,,t-1,sex]) + bsex*(1-states[br,,t,nsex])
      } else {
        t1 <- g + bsi*states[1,,t,sex] + bli*states[2,,t,sex] + bt*(states[br,,t-1,sex]+states[br,,t+1,sex]) + bsex*states[br,,t,nsex]
        t0 <- bsi*(1-states[1,,t,sex]) + bli*(1-states[2,,t,sex]) + bt*(1-states[br,,t-1,sex]+1-states[br,,t+1,sex]) + bsex*(1-states[br,,t,nsex])
      }
      states[br,,t,sex] <- ((exp(t1)/(exp(t1) + exp(t0))) > runif(ng)) + 0
    }   
  }
  return(states)
}

getStatesSimhmm <- function(nbr=3, ng=500, nt=5, numsex=2, nDE, tch, perc){
  states <- array(0, dim=c(nbr, ng, nt, numsex))
  stmp <- matrix(0,nrow=ng, ncol=nt)
  tmp <- sample(ng, round(ng*nDE), replace=F)
  stmp[tmp, 1] <- 1
  for (t in 2:nt){
    e1 <- which(stmp[, t-1]==1)
    e0 <- which(stmp[, t-1]==0)
    
    ne1 <- sum(stmp[, t-1])
    ct <- round(ne1*tch)
    
    e1n <- c(sample(e1, ne1-ct, replace=F), sample(e0, ct, replace=F))
    stmp[e1n, t] <- 1    
  }
  for (b in 1:nbr){
    for (s in 1:numsex){
      states[b,,,s] <- stmp
    }
  }
  l1 <- which(states==1)
  l0 <- which(states==0)
  c10 <- sample(l1, round(length(l1)*perc), replace=F)
  c01 <- sample(l0, round(length(l1)*perc), replace=F)
  states[c(c10,c01)] <- 1 - states[c(c10,c01)]
  return(states)
}


